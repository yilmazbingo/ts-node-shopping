// import path from "path";
// import DataUri from "datauri";

// const dUri = new DataUri();

// export const dataUri = (file: Express.Multer.File): string =>
//   dUri.format(path.extname(file.originalname).toString(), file.buffer);
